const yup = require('yup')
const validateReservation = async (req, res, next) => {
  try {
    const schema = yup.object().shape({
      nomclient: yup.string().min(3).required(),
      cin: yup.string().required(),
      email: yup.string().email().required(),
      nombrepersonne: yup.number().min(1).required(),
      prixparnuit: yup.number().min(1).required(),
      datearrivee: yup.date().required(),
      datedepart: yup.date().min(yup.ref('datearrivee'), 'La date de depart doit être après la date darivee').required(),
      statut: yup.string().oneOf(['en attente', 'confirmée', 'annulée']),
      referencevilla: yup.string()
    })
    await schema.validate(req.body, { abortEarly: false })
    next()
  } catch (error) {
    res.status(400).json({ error: error.errors })
  }
}

module.exports = validateReservation 
