const yup = require('yup')
const validateClassroom = async (req, res, next) => {
  try {
    const schema = yup.object().shape({
      name: yup.string().min(3).required(),
      floor: yup.number().min(0).required(),
      capacity: yup.number().required(),
      date: yup.date().default(() => new Date()).required()
    })
    await schema.validate(req.body, { abortEarly: false })
    next()
  } catch (error) {
    res.status(400).json({ error: error.errors })
  }
}

module.exports = validateClassroom 