const mongoose = require('mongoose')
const Schema = mongoose.Schema

const Classroom = new Schema({
  name: { type: String, required: true, minlength: 3 },
  floor: { type: Number, required: true, min: 0 },
  capacity: { type: Number, required: true },
  date: { type: Date, required: true, default: Date.now }
})

module.exports = mongoose.model('classrooms', Classroom) 