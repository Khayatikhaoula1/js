const mongoose = require('mongoose')
const Schema = mongoose.Schema

const Reservation = new Schema({
  nomclient: { type: String, required: true, minlength: 3 },
  cin: { type: String, required: true, unique: true },
  email: { type: String, required: true },
  nombrepersonne: { type: Number, required: true, min: 1 },
  prixparnuit: { type: Number, required: true, min: 1 },
  datearrivee: { type: Date, required: true },
  datedepart: { type: Date, required: true },
  statut: { type: String, enum: ['en attente', 'confirmée', 'annulée'], default: 'en attente' },
  referencevilla: String
})

module.exports = mongoose.model('reservations', Reservation) 