const express = require('express')
const router = express.Router()
const reservationService = require('../service/reservationService')
const validate = require('../middleware/reservationValidation')

router.post('/create', validate, reservationService.create)
router.get('/list', reservationService.read)
router.get('/details/:id', reservationService.readOne)
router.put('/update/:id', validate, reservationService.update)
router.delete('/delete/:id', reservationService.deleteC)
router.get('/search', reservationService.search)
router.get('/stats', reservationService.stats)

module.exports = router 

