const express = require('express')
const router = express.Router()
const classroomService = require('../service/classroomService')
const validate = require('../middleware/classroomValidation')

router.post('/create', validate, classroomService.create)
router.get('/list', classroomService.read)
router.get('/details/:id', classroomService.readOne)
router.put('/update/:id', validate, classroomService.update)
router.delete('/delete/:id', classroomService.deleteC)

// Bonus
router.get('/search/floor', classroomService.findByFloor)
router.get('/stat/capacity', classroomService.sumCapacity)
router.get('/sorted/date', classroomService.listSortedByDate)
router.get('/show', classroomService.showClassrooms)

module.exports = router 