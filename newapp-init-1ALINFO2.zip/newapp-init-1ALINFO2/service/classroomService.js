const Classroom = require('../model/classroomModel')

// CREATE
const create = async (req, res, next) => {
  try {
    const classroom = new Classroom(req.body)
    await classroom.save()
    res.json({ msg: 'Classroom created!', classroom })
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

const read = async (req, res, next) => {
  try {
    const classrooms = await Classroom.find()
    res.json(classrooms)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

const readOne = async (req, res, next) => {
  try {
    const classroom = await Classroom.findById(req.params.id)
    if (!classroom) return res.status(404).json({ error: 'Not found' })
    res.json(classroom)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

const update = async (req, res, next) => {
  try {
    const classroom = await Classroom.findByIdAndUpdate(req.params.id, req.body, { new: true })
    if (!classroom) return res.status(404).json({ error: 'Not found' })
    res.json({ msg: 'Classroom updated!', classroom })
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

const deleteC = async (req, res, next) => {
  try {
    const classroom = await Classroom.findByIdAndDelete(req.params.id)
    if (!classroom) return res.status(404).json({ error: 'Not found' })
    res.json({ msg: 'Classroom deleted!', classroom })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// BONUS 1: Find classrooms with floor between X and Y
const findByFloor = async (req, res, next) => {
  const { min, max } = req.query
  try {
    const classrooms = await Classroom.find({ floor: { $gte: Number(min), $lte: Number(max) } })
    res.json(classrooms)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

// BONUS 2: Sum of capacities where capacity > 10
const sumCapacity = async (req, res, next) => {
  try {
    const result = await Classroom.aggregate([
      { $match: { capacity: { $gt: 10 } } },
      { $group: { _id: null, total: { $sum: "$capacity" } } }
    ])
    res.json({ total: result[0]?.total || 0 })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// BONUS 3: List classrooms sorted by date
const listSortedByDate = async (req, res, next) => {
  try {
    const classrooms = await Classroom.find().sort({ date: 1 })
    res.json(classrooms)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

const showClassrooms = async (req, res, next) => {
  try {
    const classrooms = await Classroom.find().sort({ date: 1 })
    res.render('classroom.html.twig', { classrooms })
  } catch (error) {
    res.status(500).send('Erreur affichage classrooms')
  }
}

module.exports = { create, read, readOne, update, deleteC, findByFloor, sumCapacity, listSortedByDate, showClassrooms } 