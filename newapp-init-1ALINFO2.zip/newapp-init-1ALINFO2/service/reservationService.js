const Reservation = require('../model/reservationModel')

const create = async (req, res, next) => {
  try {
    const reservation = new Reservation({ ...req.body, statut: 'en attente' })
    await reservation.save()
    res.json({ msg: 'Réservation cree !', reservation })
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

const read = async (req, res, next) => {
  try {
    const reservations = await Reservation.find()
    res.json(reservations)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

const readOne = async (req, res, next) => {
  try {
    const reservation = await Reservation.findById(req.params.id)
    if (!reservation) return res.status(404).json({ error: 'Not found' })
    res.json(reservation)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// 
const update = async (req, res, next) => {
  try {
    const reservation = await Reservation.findByIdAndUpdate(req.params.id, req.body, { new: true })
    if (!reservation) return res.status(404).json({ error: 'Not found' })
    res.json({ msg: 'Réservation modifiée !', reservation })
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}


const deleteC = async (req, res, next) => {
  try {
    const reservation = await Reservation.findByIdAndDelete(req.params.id)
    if (!reservation) return res.status(404).json({ error: 'Not found' })
    res.json({ msg: 'Réservation supprimée !', reservation })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}


const search = async (req, res, next) => {
  const { nomclient, cin } = req.query
  try {
    const query = {}
    if (nomclient) query.nomclient = { $regex: nomclient, $options: 'i' }
    if (cin) query.cin = cin
    const reservations = await Reservation.find(query)
    res.json(reservations)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}
//1 jour = 24 * 60 * 60 * 1000 = 86 400 000 millis
const stats = async (req, res, next) => {
  try {
    const total = await Reservation.countDocuments()
    const all = await Reservation.find()
    let montantTotal = 0
    let reservationMax = null
    let montantMax = 0
    all.forEach(r => {
      let nbNuits = (r.datedepart - r.datearrivee) / 86400000
      if(nbNuits < 1) nbNuits = 1
      let montant = r.prixparnuit * nbNuits
      montantTotal += montant
      if (montant > montantMax) {
        montantMax = montant
        reservationMax = r
      }
    })
    res.json({
      total,
      reservationMontantMax: reservationMax,
      montantTotal
    })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

module.exports = { create, read, readOne, update, deleteC, search, stats } 